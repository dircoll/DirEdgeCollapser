#include <iostream>
#include <fstream>
#include <iomanip>

int main() {
    int n;
    double edge_filt;
    std::string filename;

    std::cout << "Enter number of vertices: ";
    std::cin >> n;

    std::cout << "Enter filtration value for all edges: ";
    std::cin >> edge_filt;

    std::cout << "Enter output .flag filename: ";
    std::cin >> filename;

    std::ofstream outfile(filename);
    if (!outfile) {
        std::cerr << "Error opening file for writing.\n";
        return 1;
    }

    // Write dim 0 vertices
    outfile << "dim 0:\n";
    for (int i = 0; i < n; ++i) {
        outfile << "0 ";
    }
    outfile << "\n";

    // Write dim 1 edges
    outfile << "dim 1:\n";
    outfile << std::fixed << std::setprecision(3);
    for (int u = 0; u < n; ++u) {
        for (int v = u + 1; v < n; ++v) {
            outfile << u << " " << v << " " << edge_filt << "\n";
        }
    }

    outfile.close();
    std::cout << "Graph written to " << filename << "\n";
    return 0;
}
