#!/bin/bash

echo "=== ER Graph Edge Removal Experiment ==="
echo "Testing edge removal on Erdős-Rényi graphs with different edge densities"

# Create output directories
mkdir -p graphs experiments

# Compile the ER experiment programs
echo "Compiling ER experiment programs..."

# Compile homology version
g++ -O3 -march=native -std=c++17 get_plot_homology.cpp -o get_plot_homology
echo "Compiled get_plot_homology"

# Compile persistence version  
g++ -O3 -march=native -std=c++17 get_plot_pers.cpp -o get_plot_persistence
echo "Compiled get_plot_persistence"

echo ""
echo "=== Running ER Graph Experiments ==="

# Run homology experiment
echo "Running homology edge removal experiment..."
echo "- Graph type: Erdős-Rényi random graphs"
echo "- Vertices: 100"  
echo "- Edge probabilities: 0.01 to 1.0 (21 different densities)"
echo "- Runs per density: 5 for better averaging"

./get_plot_homology --n 100 --runs 5 --csv results/results_er_homology.csv

echo ""
echo "Running persistence edge removal experiment..."
./get_plot_persistence --n 100 --runs 5 --csv results/results_er_persistence.csv

echo ""
echo "=== Experiment Results Generated ==="
echo "Files created:"
echo "- results/results_er_homology.csv"
echo "- results/results_er_persistence.csv"

echo ""
echo "Sample results from homology experiment:"
head -10 results/results_er_homology.csv

echo ""
echo "Sample results from persistence experiment:"  
head -10 results/results_er_persistence.csv

echo ""
echo "=== Creating Combined Edge Removal Plot ==="

# Create Python plotting script for edge removal comparison
cat > plot_edge_removal.py << 'EOF'
#!/usr/bin/env python3
import matplotlib.pyplot as plt
import pandas as pd
import sys

def create_edge_removal_plot():
    try:
        # Load CSV files
        homology_df = pd.read_csv('results/results_er_homology.csv')
        persistence_df = pd.read_csv('results/results_er_persistence.csv')
        
        # Create the plot matching your reference image style
        plt.figure(figsize=(10, 6))
        
        # Plot homology data with diamond markers (blue)
        plt.plot(homology_df['num_edges'], homology_df['percent_removed'], 
                 marker='D', linewidth=2, markersize=8, 
                 label='Homology', color='blue', markerfacecolor='blue')
        
        # Plot persistence data with circular markers (red)
        plt.plot(persistence_df['num_edges'], persistence_df['percent_removed'], 
                 marker='o', linewidth=2, markersize=8, 
                 label='Persistence', color='red', markerfacecolor='red')
        
        # Set axis labels and title
        plt.xlabel('Number of Edges')
        plt.ylabel('% Removed')
        plt.title('Edge Removal Percentage vs Number of Edges in ER Graphs')
        
        # Add grid and legend
        plt.grid(True, alpha=0.3)
        plt.legend(loc='upper right')
        
        # Set axis limits to match reference image
        plt.xlim(0, 5000)
        plt.ylim(0, 50)
        
        # Save the plot
        plt.savefig('results/edge_removal_er.png', dpi=300, bbox_inches='tight')
        
        print("Plot saved as edge_removal_er.png")
        
    except FileNotFoundError:
        print("Error: CSV files not found. Run ER experiments first.")
        return False
    except Exception as e:
        print(f"Error creating plot: {e}")
        return False

if __name__ == "__main__":
    create_edge_removal_plot()
EOF

# Run the Python plotting script
if command -v python3 &> /dev/null; then
    python3 plot_edge_removal.py
else
    echo "Python3 not available. Plot files not generated."
    echo "CSV files are available for manual plotting."
fi