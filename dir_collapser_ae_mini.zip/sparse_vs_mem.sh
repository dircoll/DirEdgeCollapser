#!/bin/bash

echo "=== Runtime Comparison Experiment ==="
echo "Comparing sparse vs memory-optimized algorithms..."

# Create graphs directory
mkdir -p graphs

# Compile benchmark programs
echo "Compiling benchmark programs..."

g++ -O3 -march=native -std=c++17 benchmark_sparse.cpp -o benchmark_sparse
g++ -O3 -march=native -std=c++17 benchmark_mem.cpp -o benchmark_mem

echo ""
echo "Running sparse algorithm benchmark..."
./benchmark_sparse

echo ""
echo "Running memory-optimized algorithm benchmark..."
./benchmark_mem

echo ""
echo "=== Benchmark Results Generated ==="
echo "- results/runtime_results_sparse.csv"
echo "- results/runtime_results_mem.csv"

echo ""
echo "Sample results from sparse algorithm:"
head -10 results/runtime_results_sparse.csv

echo ""
echo "Sample results from memory-optimized algorithm:"
head -10 results/runtime_results_mem.csv

echo ""
echo "=== Generating Runtime Comparison Plot ==="

# Create Python plotting script
cat > plot_runtime.py << 'EOF'
#!/usr/bin/env python3
import matplotlib.pyplot as plt
import pandas as pd
import sys

try:
    # Load CSV files
    sparse_df = pd.read_csv('results/runtime_results_sparse.csv')
    mem_df = pd.read_csv('results/runtime_results_mem.csv')
    
    # Create the plot
    plt.figure(figsize=(10, 6))
    plt.plot(sparse_df['vertices'], sparse_df['runtime_ms'], 
             marker='s', linewidth=2, markersize=6, label='Sparse Algorithm', color='red')
    plt.plot(mem_df['vertices'], mem_df['runtime_ms'], 
             marker='^', linewidth=2, markersize=6, label='Memory-optimised Algorithm', color='blue')
    
    plt.xlabel('Number of Vertices')
    plt.ylabel('Runtime (ms)')
    plt.title('Algorithm Runtime Comparison')
    plt.grid(True, alpha=0.3)
    plt.legend(loc='upper left')
    
    # Set axis limits to match reference image
    plt.xlim(0, 200)
    plt.ylim(0, max(max(sparse_df['runtime_ms']), max(mem_df['runtime_ms'])) * 1.1)
    
    # Save the plot
    plt.savefig('results/runtime_comparison.png', dpi=300, bbox_inches='tight')
    
    print("Plot saved as results/runtime_comparison.png")
    
except FileNotFoundError as e:
    print(f"Error: Could not find CSV files. Make sure benchmark programs ran successfully.")
    sys.exit(1)
except Exception as e:
    print(f"Error creating plot: {e}")
    sys.exit(1)
EOF

# Run the Python plotting script
if command -v python3 &> /dev/null; then
    python3 plot_runtime.py
else
    echo "Python3 not available. Plot files not generated."
    echo "CSV files are available for manual plotting."
fi
