#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <random>
#include <algorithm>
#include <iomanip>

int main() {
    int n, m;
    double min_time = 0.0, max_time = 1.0;
    std::string filename;

    std::cout << "Enter number of vertices (n): ";
    std::cin >> n;

    std::cout << "Enter number of directed edges (m): ";
    std::cin >> m;

    std::cout << "Enter output .flag filename: ";
    std::cin >> filename;

    int max_edges = n * (n - 1) / 2;
    if (m > max_edges) {
        std::cerr << "Too many edges. Maximum without reciprocal pairs: " << max_edges << "\n";
        return 1;
    }

    std::ofstream outfile(filename);
    if (!outfile) {
        std::cerr << "Error opening file.\n";
        return 1;
    }

    // dim 0: vertex filtration values (all 0)
    outfile << "dim 0:\n";
    for (int i = 0; i < n; ++i) {
        outfile << "0 ";
    }
    outfile << "\n";

    // Prepare all unordered pairs (i, j) with i < j
    std::vector<std::pair<int, int> > base_pairs;
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            base_pairs.push_back(std::make_pair(i, j));
        }
    }

    // Shuffle and select m pairs
    std::random_device rd;
    std::mt19937 rng(rd());
    std::shuffle(base_pairs.begin(), base_pairs.end(), rng);

    std::uniform_real_distribution<double> time_dist(min_time, max_time);

    // Write dim 1
    outfile << "dim 1:\n";
    for (int i = 0; i < m; ++i) {
        auto p = base_pairs[i];
        // Randomly choose direction (p.first -> p.second) or (p.second -> p.first)
        bool flip = rng() % 2;
        int u = flip ? p.second : p.first;
        int v = flip ? p.first : p.second;
        double t = time_dist(rng);
        outfile << u << " " << v << " " << std::fixed << std::setprecision(3) << 1 << "\n";
    }

    outfile.close();
    std::cout << "Directed graph written to " << filename << "\n";
    return 0;
}
