#!/bin/bash

# # Create output directory
# mkdir -p post_collapse

# Check if pre_collapse directory exists
if [ ! -d "pre_collapse" ]; then
    echo "Error: pre_collapse directory not found"
    exit 1
fi

echo "Starting DirEdgeCollapser_mult batch processing..."
echo "Processing files from: pre_collapse/"
echo "Output files will be saved to: post_collapse/"
echo ""

# Find all .flag files in pre_collapse directory
flag_files=$(find pre_collapse -name "*.flag" -type f)

if [ -z "$flag_files" ]; then
    echo "No .flag files found in the pre_collapse directory."
    exit 1
fi

# Count total files
total_files=$(echo "$flag_files" | wc -l)
echo "Found $total_files .flag files to process"
echo ""

# Process each file
current=0
success_count=0
failed_count=0

for input_file in $flag_files; do
    current=$((current + 1))
    
    # Extract base filename without extension and path
    base_name=$(basename "$input_file" .flag)
    
    # Create output filename
    output_file="post_collapse/${base_name}_out.flag"
    
    echo "[$current/$total_files] Processing: $input_file"
    echo "  Output: $output_file"
    
    # Run DirEdgeCollapser_mult
    if ./../../DirEdgeCollapser_mult "$input_file" "$output_file" > "../../results/collapser_outputs/${base_name}_collapse.txt"; then
        echo "  Status: SUCCESS"
        success_count=$((success_count + 1))
    else
        echo "  Status: FAILED"
        failed_count=$((failed_count + 1))
    fi
    
    echo ""
done

echo "Batch processing complete!"
echo ""
echo "Summary:"
echo "  Total files processed: $total_files"
echo "  Successful: $success_count"
echo "  Failed: $failed_count"
echo ""
echo "Output files saved in: post_collapse/"
