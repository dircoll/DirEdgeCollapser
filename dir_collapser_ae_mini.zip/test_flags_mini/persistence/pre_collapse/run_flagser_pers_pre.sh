#!/bin/bash

# Check if flagser executable exists
if [ ! -f "./../../../flagser" ]; then
    echo "Error: flagser executable not found at ./../../../flagser"
    exit 1
fi

# Create output directory for results
mkdir -p results

# Create CSV file for results
results_file="../../../results/pers_pre_flagser_results.csv"
echo "filename,execution_time_seconds,max_memory_kb,peak_memory_mb,status" > "$results_file"

# Define files that need the --approximate flag
approximate_files=("wco_pers")

# Function to check if file needs approximate flag
needs_approximate() {
    local base_name="$1"
    for approx_file in "${approximate_files[@]}"; do
        if [[ "$base_name" == "$approx_file" ]]; then
            return 0  # True
        fi
    done
    return 1  # False
}

# Function to run flagser with time and memory measurement
run_flagser() {
    local input_file="$1"
    local base_name=$(basename "$input_file" .flag)
    local output_file="results/${base_name}.homology"
    
    echo "Processing: $input_file"
    
    # Use /usr/bin/time to measure execution time and memory
    # -v gives verbose output including maximum resident set size
    time_output=$(mktemp)
    
    # Determine which command to run based on filename
    if needs_approximate "$base_name"; then
        echo "  Using approximate mode for $base_name"
        # Run with --approximate flag
        /usr/bin/time -v -o "$time_output" \
            ./../../../flagser --filtration max --approximate 10000 --out "$output_file" "$input_file" 2>&1
    else
        # Run with standard flags
        /usr/bin/time -v -o "$time_output" \
            ./../../../flagser --filtration max --out "$output_file" "$input_file" 2>&1
    fi
    
    exit_code=$?
    
    # Parse the time output
    if [ -f "$time_output" ]; then
        # Extract execution time (User time + System time)
        user_time=$(grep "User time" "$time_output" | awk '{print $4}')
        system_time=$(grep "System time" "$time_output" | awk '{print $4}')
        
        # Extract maximum resident set size (memory in KB)
        max_memory_kb=$(grep "Maximum resident set size" "$time_output" | awk '{print $6}')
        
        # Calculate total time and convert memory to MB
        total_time=$(echo "$user_time + $system_time" | bc -l)
        max_memory_mb=$(echo "scale=2; $max_memory_kb / 1024" | bc -l)
        
        # Determine status
        if [ $exit_code -eq 0 ]; then
            status="SUCCESS"
        else
            status="FAILED"
        fi
        
        # Write results to CSV
        echo "$base_name,$total_time,$max_memory_kb,$max_memory_mb,$status" >> "$results_file"
        
        # Print summary
        echo "  Time: ${total_time}s"
        echo "  Memory: ${max_memory_mb}MB"
        echo "  Status: $status"
        echo "  Output: $output_file"
        echo ""
        
    else
        echo "Error: Could not capture timing information for $input_file"
        echo "$base_name,ERROR,ERROR,ERROR,ERROR" >> "$results_file"
    fi
    
    # Clean up temporary file
    rm -f "$time_output"
}

# Main execution
echo "Starting flagser batch processing..."
echo "Results will be saved to: $results_file"
echo ""

# Find all .flag files and process them
flag_files=$(find . -name "*.flag" -type f)

if [ -z "$flag_files" ]; then
    echo "No .flag files found in the current directory and subdirectories."
    exit 1
fi

# Count total files
total_files=$(echo "$flag_files" | wc -l)
echo "Found $total_files .flag files to process"
echo ""

# Process each file
current=0
for file in $flag_files; do
    current=$((current + 1))
    echo "[$current/$total_files] Processing: $file"
    run_flagser "$file"
done

echo "Batch processing complete!"
echo "Results saved to: $results_file"
echo ""
echo "Summary statistics:"
awk -F',' 'NR>1 && $5=="SUCCESS" {
    sum_time += $2; 
    sum_memory += $4; 
    count++
} 
END {
    if(count > 0) {
        printf "Successful runs: %d\n", count
        printf "Average time: %.2f seconds\n", sum_time/count
        printf "Average memory: %.2f MB\n", sum_memory/count
    }
}' "$results_file"
