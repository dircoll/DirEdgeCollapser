#include <iostream>
#include <fstream>
#include <chrono>
#include <cstdlib>
#include <string>
#include <iomanip>

void generate_graph(int n, const std::string& filename) {
    std::ofstream outfile(filename);
    outfile << "dim 0:\n";
    for (int i = 0; i < n; ++i) {
        outfile << "0 ";
    }
    outfile << "\n";

    outfile << "dim 1:\n";
    for (int u = 0; u < n; ++u) {
        for (int v = u + 1; v < n; ++v) {
            outfile << u << " " << v << " 1.000\n";
        }
    }
    outfile.close();
}

int main() {
    const int start_n = 10;
    const int end_n = 200;     // adjust as needed
    const int step = 10;

    std::ofstream csv("results/runtime_results_mem.csv");
    csv << "vertices,runtime_ms\n";

    for (int n = start_n; n <= end_n; n += step) {
        std::string graph_file = "graphs/graph_" + std::to_string(n) + ".flag";
        std::string out_file = "graphs/processed_" + std::to_string(n) + ".flag";

        generate_graph(n, graph_file);

        auto start = std::chrono::high_resolution_clock::now();

        std::string command = "./DirEdgeCollapser_mem " + graph_file + " " + out_file;
        int exit_code = system(command.c_str());

        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double, std::milli> elapsed = end - start;

        if (exit_code != 0) {
            std::cerr << "Error: DirEdgeCollapser_mem failed on n = " << n << "\n";
            continue;
        }

        std::cout << "n = " << n << " runtime = " << elapsed.count() << " ms\n";
        csv << n << "," << std::fixed << std::setprecision(3) << elapsed.count() << "\n";
    }

    csv.close();
    std::cout << "Benchmarking completed. Results saved to runtime_results_mem.csv\n";

    return 0;
}
