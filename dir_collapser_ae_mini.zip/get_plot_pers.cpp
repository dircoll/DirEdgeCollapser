#include <iostream>
#include <fstream>
#include <vector>
#include <random>
#include <set>
#include <tuple>
#include <string>
#include <cstdlib>
#include <sstream>
#include <numeric>

using Vertex = int;
using Edge = std::tuple<Vertex, Vertex, double>;

std::vector<Edge> generate_er_graph(int num_vertices, double edge_prob, double weight_min, double weight_max, int seed) {
    std::vector<Edge> edges;
    std::mt19937 gen(seed);
    std::uniform_real_distribution<> prob_dist(0.0, 1.0);
    std::uniform_real_distribution<> direction_dist(0.0, 1.0);
    std::uniform_real_distribution<> weight_dist(weight_min, weight_max);
    std::set<std::pair<Vertex, Vertex>> added;

    for (int i = 0; i < num_vertices; ++i) {
        for (int j = 0; j < num_vertices; ++j) {
            if (i == j) continue; // No self-loop
            if (added.count({j, i})) continue; // Skip reciprocal edge
            if (added.count({i, j})) continue; // Skip if already added
            if (prob_dist(gen) < edge_prob) {
                double weight = weight_dist(gen);
                // Randomly choose direction
                if (direction_dist(gen) < 0.5) {
                    edges.emplace_back(i, j, weight);
                    added.insert({i, j});
                } else {
                    edges.emplace_back(j, i, weight);
                    added.insert({j, i});
                }
            }
        }
    }
    return edges;
}


void write_flag_file(const std::string& filename, int num_vertices, const std::vector<Edge>& edges) {
    std::ofstream fout(filename);
    fout << "dim 0:\n";
    for (int i = 0; i < num_vertices; ++i) fout << 0 << " ";
    fout << "\n";

    fout << "dim 1:\n";
    for (const auto& [u, v, w] : edges) {
        fout << u << " " << v << " " << w << "\n";
    }
    fout.close();
}

int count_edges(const std::string& filename) {
    std::ifstream fin(filename);
    std::string line;
    bool in_edges = false;
    int edge_count = 0;

    while (getline(fin, line)) {
        if (line.find("dim 1:") != std::string::npos) {
            in_edges = true;
            continue;
        }
        if (in_edges && !line.empty()) ++edge_count;
    }
    return edge_count;
}

int main(int argc, char* argv[]) {
    int seed = 42;
    int num_vertices = 100;
    int runs = 1;
    std::string csv_file = "results_er_homology.csv";

    // Parse command-line arguments
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--seed" && i + 1 < argc) {
            seed = std::stoi(argv[++i]);
        } else if (arg == "--csv" && i + 1 < argc) {
            csv_file = argv[++i];
        } else if (arg == "--n" && i + 1 < argc) {
            num_vertices = std::stoi(argv[++i]);
        } else if (arg == "--runs" && i + 1 < argc) {
            runs = std::stoi(argv[++i]);
        }
    }

    std::vector<double> probs = {0.01, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1};

    std::ofstream result_file(csv_file);
    if (!result_file) {
        std::cerr << "Failed to open file: " << csv_file << "\n";
        return 1;
    }

    result_file << "num_edges,percent_removed\n";

    for (int i = 0; i < probs.size(); ++i) {
        std::vector<int> edge_counts;
        std::vector<double> percents;

        for (int r = 0; r < runs; ++r) {
            std::string input_file = "graphs/input_" + std::to_string(i) + "_run" + std::to_string(r) + ".flag";
            std::string output_file = "graphs/output_" + std::to_string(i) + "_run" + std::to_string(r) + ".flag";

            auto edges = generate_er_graph(num_vertices, probs[i], 0.0, 1.0, seed + i * runs + r);
            write_flag_file(input_file, num_vertices, edges);

            int before = edges.size();
            std::string command = "./DirEdgeCollapser_mult " + input_file + " " + output_file;
            int ret = std::system(command.c_str());
            if (ret != 0) {
                std::cerr << "Command failed: " << command << "\n";
                continue;
            }

            int after = count_edges(output_file);
            double percent_removed = 100.0 * (before - after) / before;

            edge_counts.push_back(before);
            percents.push_back(percent_removed);

            std::cout << "[p=" << probs[i] << " run=" << r << "] "
                      << "edges: " << before << " → " << after
                      << " (" << percent_removed << "% removed)\n";
        }

        if (!edge_counts.empty()) {
            double avg_edges = std::accumulate(edge_counts.begin(), edge_counts.end(), 0.0) / edge_counts.size();
            double avg_percent = std::accumulate(percents.begin(), percents.end(), 0.0) / percents.size();
            result_file << avg_edges << "," << avg_percent << "\n";
        }
    }

    result_file.close();
    std::cout << "Averaged results written to " << csv_file << "\n";
    return 0;
}
