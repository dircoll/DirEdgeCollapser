#!/bin/bash

# Redirect all script output to a text file
exec > results/50_complete_graph_output.txt 2>&1

echo "=== Complete Graph Edge Collapse Experiment ==="
echo "Testing both ordered and random graphs on 50 vertices..."

# Step 1: Compile both graph generators
echo "Compiling graph generators..."

if [ ! -f generate_flag ]; then
    echo "Compiling generate_flag.cpp..."
    g++ -O3 -march=native -std=c++17 generate_flag.cpp -o generate_flag
fi

if [ ! -f generate_flag_random ]; then
    echo "Compiling generate_flag_random.cpp..."
    g++ -O3 -march=native -std=c++17 generate_flag_random.cpp -o generate_flag_random
fi

echo ""
echo "=== Generating Graphs ==="

# Step 2: Generate complete graph with 50 vertices
echo "Generating ordered graph (50 vertices)..."
./generate_flag <<EOF
50
1.0
complete_graph.flag
EOF

# Step 3: Generate random graph with 50 vertices
echo "Generating random graph (50 vertices)..."
./generate_flag_random <<EOF
50
1225
random_graph.flag
EOF

echo ""
echo "Graph Statistics:"
echo "- Ordered graph: 50 vertices, 1225 edges"
echo "- Random graph: 50 vertices, 1225 edges"

echo ""
echo "=== Running DirEdgeCollapser_mem_mult Algorithm ==="

# Step 4: Run algorithm on complete graph
echo "Processing ordered graph..."
./DirEdgeCollapser_mem_mult complete_graph.flag complete_graph_out.flag > complete_output.txt

# Step 5: Run algorithm on random graph
echo "Processing random graph..."
./DirEdgeCollapser_mem_mult random_graph.flag random_graph_out.flag > random_output.txt

echo ""
echo "=== Edge Reduction Progressions ==="
echo ""

echo "ORDERED GRAPH:"
echo "=============================================="
awk '/Iteration Summary/,/Final Statistics/' complete_output.txt | head -n -1

echo ""
echo "RANDOM GRAPH:"
echo "========================================="
awk '/Iteration Summary/,/Final Statistics/' random_output.txt | head -n -1

echo ""
echo "=== Experiment Completed Successfully ==="
echo "Results saved to: results/50_complete_graph_output.txt"
