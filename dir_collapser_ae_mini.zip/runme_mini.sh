#!/bin/bash

echo "=================================================================="
echo "  DIRECTED EDGE COLLAPSER (MINI) EXPERIMENTS"
echo "=================================================================="
echo ""
echo "Experiments included:"
echo "  1. 50-vertex complete graph edge collapse analysis"
echo "  2. Runtime comparison: sparse vs memory-optimized algorithms" 
echo "  3. ER graph edge removal percentage across densities"
echo "  4. Flagser homology/persistence computation pre/post collapse (for select datasets)"
echo ""
echo "=================================================================="
echo ""

mkdir -p results/collapser_outputs

# Function to check if script exists and is executable
check_script() {
    if [ ! -f "$1" ]; then
        echo "ERROR: Script $1 not found!"
        return 1
    fi
    if [ ! -x "$1" ]; then
        echo "Making $1 executable..."
        chmod +x "$1"
    fi
    return 0
}

# Function to run exps
run_experiment() {
    local script_name="$1"
    local description="$2"
    
    echo "Starting: $description"
    echo "Running: $script_name"
    
    start_time=$(date +%s)
    
    if ! check_script "$script_name"; then
        echo "FAILED: Cannot run $script_name"
        return 1
    fi
    
    if ./"$script_name"; then
        end_time=$(date +%s)
        duration=$((end_time - start_time))
        echo "COMPLETED: $description (${duration}s)"
    else
        echo "FAILED: $description"
        return 1
    fi
    echo ""
}

# Function to run flagser exps
run_flagser_experiment() {
    local base_dir="$1"
    local collapser_script="$2"
    local pre_script="$3" 
    local post_script="$4"
    
    echo "Starting: Flagser experiment at $base_dir"
    
    if [ ! -d "$base_dir" ]; then
        echo "ERROR: Directory $base_dir not found!"
        return 1
    fi
    
    cd "$base_dir" || return 1
    
    # Run collapser
    if ! run_experiment "$collapser_script" "Edge collapse with $collapser_script"; then
        cd - > /dev/null || return 1
        return 1
    fi
    
    # Run pre-collapse flagser
    if [ -d "pre_collapse" ]; then
        cd pre_collapse || return 1
        if ! run_experiment "$pre_script" "Pre-collapse analysis with $pre_script"; then
            cd - > /dev/null || return 1
            return 1
        fi
        cd .. || return 1
    fi
    
    # Run post-collapse flagser
    if [ -d "post_collapse" ]; then
        cd post_collapse || return 1
        if ! run_experiment "$post_script" "Post-collapse analysis with $post_script"; then
            cd - > /dev/null || return 1
            return 1
        fi
        cd .. || return 1
    fi
    
    cd ../../ > /dev/null || return 1
    echo "COMPLETED: Flagser experiment at $base_dir"
    echo ""
}


# =================================================================
# EXPERIMENT 1: 50 Vertex Complete Graph Edge Collapse
# =================================================================

run_experiment "50_graph_exp.sh" "50 Vertex Complete Graph Edge Collapse Experiment"

# =================================================================
# EXPERIMENT 2: Runtime Comparison (Sparse vs Memory-Optimized)
# =================================================================

run_experiment "sparse_vs_mem.sh" "Sparse vs Memory-Optimized Runtime Comparison"

# =================================================================
# EXPERIMENT 3: ER Graph Edge Removal Percentage
# =================================================================

run_experiment "er_edge_removal.sh" "ER Graph Edge Removal Percentage Analysis"

# =================================================================
# EXPERIMENT 4: Flagser Pre/Post Collapse Comparison
# =================================================================

echo "Starting: Flagser Pre/Post Collapse Comparison Suite"
echo ""

# Check if test_flags_mini directory exists
if [ ! -d "test_flags_mini" ]; then
    echo "ERROR: test_flags_mini directory not found!"
    echo "Expected structure: test_flags_mini/{homology,persistence}/{pre_collapse,post_collapse}/"
    exit 1
fi

# 4a. Homology experiments
run_flagser_experiment "test_flags_mini/homology" "hom_collapser.sh" "run_flagser_hom_pre.sh" "run_flagser_hom_post.sh"

# 4b. Persistence experiments  
run_flagser_experiment "test_flags_mini/persistence" "pers_collapser.sh" "run_flagser_pers_pre.sh" "run_flagser_pers_post.sh"

# =================================================================
# COMPLETION SUMMARY
# =================================================================

echo "=================================================================="
echo "  ALL EXPERIMENTS COMPLETED SUCCESSFULLY"
echo "=================================================================="
echo ""
echo "Output files can be found in ./results/"
echo ""
echo "For detailed analysis, examine individual result files"
echo "and generated visualizations."
echo "=================================================================="
